from django.contrib import admin
from .models import Appointment,TakeAppointment


admin.site.register(Appointment)
admin.site.register(TakeAppointment)