from django.urls import path
from .views import *

urlpatterns = [
    path('',index,name='home'),
    path('diabetes/',diabetes,name='diabetes'),
    path('breast/',breast,name='breast'),
    path('brain/',brain_disease_prediction,name='brain'),
    path('heart/',heart,name='heart'),
    path('lung_cancer/',lung_cancer,name='lung_cancer'),
    path('post/<int:post_id>/', blog_post_detail, name='blog_post_detail'),
]
